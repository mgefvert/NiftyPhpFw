<?php

header('Location: blog/');
